/* ===== 更多 / AI助手 / 帮助 / 搜索 / 关联 / 更新日志 ===== */
window.Views = window.Views || {};

/* ---------- 全局搜索 ---------- */
const Search = (() => {
  function results(kw) {
    if (!kw) return `<div class="muted" style="padding:24px;text-align:center">输入关键词，搜索学员 / 待办 / 课表 / 话术</div>`;
    const k = kw.toLowerCase();
    const stu = DB.data.students.filter(s => (s.code + s.parentName + s.grade + s.subject).toLowerCase().includes(k));
    const todo = DB.data.todos.filter(t => t.title.toLowerCase().includes(k));
    const les = DB.data.lessons.filter(l => { const s = DB.student(l.studentId); return (s && (s.parentName + s.grade + s.subject).toLowerCase().includes(k)) || (l.note || '').toLowerCase().includes(k); });
    const ph = DB.data.phrases.filter(p => (p.title + p.content).toLowerCase().includes(k));
    let h = '';
    if (stu.length) h += `<div class="search-grp">学员档案 · ${stu.length}</div>` + stu.slice(0, 8).map(s =>
      `<div class="search-row" data-go="students"><div class="si" style="background:${U.subColor(s.subject)}">${U.esc(s.parentName.slice(0, 1))}</div>
       <div><div class="st">${U.esc(s.parentName)}</div><div class="ss">${U.esc(s.grade + s.subject)} · ${U.esc(s.code)}</div></div></div>`).join('');
    if (todo.length) h += `<div class="search-grp">待办 · ${todo.length}</div>` + todo.slice(0, 8).map(t =>
      `<div class="search-row" data-go="todo"><div class="si" style="background:#f2b544">待</div>
       <div><div class="st">${U.esc(t.title)}</div><div class="ss">${U.cnDate(t.date)} · ${t.done ? '已完成' : '未完成'}</div></div></div>`).join('');
    if (les.length) h += `<div class="search-grp">课表 · ${les.length}</div>` + les.slice(0, 8).map(l => {
      const s = DB.student(l.studentId) || {};
      return `<div class="search-row" data-go="schedule"><div class="si" style="background:${U.subColor(s.subject)}">课</div>
       <div><div class="st">${U.esc((s.grade || '') + (s.subject || '') + '·' + (s.parentName || ''))}</div><div class="ss">${l.date} ${l.start} · ${U.money(l.tuition)}</div></div></div>`;
    }).join('');
    if (ph.length) h += `<div class="search-grp">话术 · ${ph.length}</div>` + ph.slice(0, 8).map(p =>
      `<div class="search-row" data-go="scripts"><div class="si" style="background:#8fb8f0">话</div>
       <div><div class="st">${U.esc(p.title)}</div><div class="ss">${U.esc(p.content.slice(0, 22))}…</div></div></div>`).join('');
    return h || `<div class="muted" style="padding:24px;text-align:center">没有匹配「${U.esc(kw)}」的结果</div>`;
  }
  function open() {
    const m = U.modal({ title: '全局搜索', hideFoot: true, wide: true, body:
      `<div class="search-panel">
        <div class="search-bar"><svg class="ico"><use href="#i-search"/></svg>
          <input id="sIn" placeholder="搜索学员、待办、课表、话术…" autocomplete="off"></div>
        <div class="search-res" id="sRes"></div>
      </div>` });
    const inp = U.$('#sIn', m.body), res = U.$('#sRes', m.body);
    const run = () => {
      res.innerHTML = results(inp.value.trim());
      res.querySelectorAll('[data-go]').forEach(r => r.onclick = () => { r.closest('.mask').remove(); App.go(r.dataset.go); });
    };
    inp.addEventListener('input', run);
    inp.focus(); run();
  }
  return { open };
})();

/* ---------- 更多 / 我的 ---------- */
const More = (() => {
  const tiles = [
    { act: 'search', ic: 'i-search', name: '搜索', desc: '全局查找' },
    { go: 'ai', ic: 'i-ai', name: 'AI 助手', desc: '逸云小助手' },
    { go: 'help', ic: 'i-help', name: '帮助', desc: '使用指南' },
    { go: 'changelog', ic: 'i-log', name: '更新日志', desc: '版本记录' }
  ];
  function render() {
    const root = U.$('#view');
    if (!root || App.route !== 'more') return;
    root.innerHTML = `
    <div class="card" style="margin-bottom:16px;background:linear-gradient(120deg,#fff,#fff4f8);border-color:var(--pink-200)">
      <div style="display:flex;align-items:center;gap:12px">
        <div class="brand-mark" style="width:42px;height:42px;color:var(--pink-400)">
          <svg viewBox="0 0 40 40"><g fill="currentColor">
            <ellipse cx="20" cy="9" rx="5" ry="7.5"/><ellipse cx="30.4" cy="16.6" rx="5" ry="7.5" transform="rotate(72 30.4 16.6)"/>
            <ellipse cx="26.5" cy="28.8" rx="5" ry="7.5" transform="rotate(144 26.5 28.8)"/><ellipse cx="13.5" cy="28.8" rx="5" ry="7.5" transform="rotate(216 13.5 28.8)"/>
            <ellipse cx="9.6" cy="16.6" rx="5" ry="7.5" transform="rotate(288 9.6 16.6)"/><circle cx="20" cy="20" r="3.4" fill="#fff7fa"/></g></svg>
        </div>
        <div>
          <h2 style="font-size:18px">我的 · 逸云阁</h2>
          <p class="muted" style="font-size:12px">所有模块与工具，在这里都能找到</p>
        </div>
      </div>
    </div>
    <div class="mt-grid">
      ${tiles.map(t => `<div class="mtile" ${t.go ? `data-go="${t.go}"` : `data-act="${t.act}"`}>
        <div class="ic"><svg class="ico"><use href="#${t.ic}"/></svg></div>
        <b>${t.name}</b><small>${t.desc}</small></div>`).join('')}
    </div>`;
    U.rebind(root, 'more', e => {
      const tile = e.target.closest('[data-go],[data-act]'); if (!tile) return;
      if (tile.dataset.go) App.go(tile.dataset.go);
      else if (tile.dataset.act === 'search') Search.open();
    });
  }
  Views.more = { title: '我的', sub: '搜索 · AI 助手 · 帮助 · 更新日志', render() { render(); } };
  return { render };
})();

/* ---------- AI 助手（本地规则问答） ---------- */
const AI = (() => {
  let log = [];
  function reply(text) {
    const q = text.trim();
    if (!q) return '说点什么吧～比如「今天有几节课」';
    if (/(你好|您好|hi|hello|在吗|你是谁)/i.test(q)) return '你好呀，我是逸云小助手～可以问我：今天有几节课、本月抽成多少、怎么新建学员等。';
    if (/(今天|今日|今天有|今天几|今天还有)/.test(q)) {
      const t = U.today();
      const ls = DB.data.lessons.filter(l => l.date === t && l.status !== 'cancelled');
      const td = DB.data.todos.filter(x => x.date === t && !x.done).length;
      return `今天排了 ${ls.length} 节课，还有 ${td} 条待办未完成。` + (ls.length ? ` 第一节 ${ls[0].start} 开始。` : ' 今天没有排课，可以专心拓客～');
    }
    if (/(抽成|赚|收入|利润|多少钱)/.test(q)) {
      const a = U.monthFirst(U.today()), b = U.monthLast(U.today());
      const m = DB.statIn(a, b, { includeScheduled: true });
      const done = DB.statIn(a, b);
      return `本月（预计）抽成收入 ${U.money(m.profit)}，已落袋 ${U.money(done.profit)}，共 ${m.count} 节课、流水 ${U.money(m.gross)}。`;
    }
    if (/(待办|任务|还有什么|要做)/.test(q)) {
      const n = Todo.pendingCount();
      return `当前共有 ${n} 条未完成的待办（含历史遗留）。打开「待办」可以查看和处理，也可以一键导入每日模板。`;
    }
    if (/(学员|学生|档案|家长)/.test(q)) {
      return `现在有 ${DB.data.students.length} 位学员档案。新建学员按你在「数据管理」里设置的编码格式录入（默认：签约日期-年级学科-家长称呼-抽成/课时费|时长），例如 240815-高二数学-李妈妈-50/300|90。`;
    }
    if (/(格式|编码|怎么填|怎么新建|怎么录)/.test(q)) {
      return '学员编码格式可在「数据管理 → 档案编码格式」里自定义：用 [日期][年级学科][家长][抽成][课时费][课时长] 占位、自定分隔符与顺序。\n默认：[日期]-[年级学科]-[家长]-[抽成]/[课时费]|[课时长]\n例：240815-高二数学-李妈妈-50/300|90\n系统会自动拆成结构化字段，分别记录对家长的课时费和我内部的抽成。';
    }
    if (/(课表|排课|冲突|时间)/.test(q)) {
      return '课表支持周/月/年视图，可拖拽改时间；同一时段允许排两节课，重叠会自动并排并红框提示，方便你确认。';
    }
    if (/(备份|导出|数据|丢失|换设备)/.test(q)) {
      return '所有数据都存在本机浏览器，不会上传。建议在「设置 - 数据管理」里定期导出 JSON 备份，换设备或清缓存前务必先备份。';
    }
    if (/(试课|回访|转换)/.test(q)) {
      return '把学员标记为「试课中」并填试课日期后，次日系统会自动在待办生成一条「回访XX妈妈试课体验」，且不会重复生成。';
    }
    if (/(财务|三本账|老师|成本)/.test(q)) {
      return '作为中间人，每节课同时记录三笔：家长流水（课时费）、老师课酬（课时费−抽成）、我的抽成。恒等式：流水 = 课酬 + 抽成。财务页可按月/年统计并排序板块。';
    }
    return '这个问题我还在学习～你可以试试问我：今天有几节课、本月抽成多少、怎么新建学员、数据怎么备份。也可以直接在对应模块操作。';
  }
  const quick = ['今天有几节课', '本月抽成多少', '怎么新建学员', '数据怎么备份'];

  function render() {
    const root = U.$('#view');
    if (!root || App.route !== 'ai') return;
    if (!log.length) log = [{ me: false, text: '你好，我是逸云小助手 🌸 有任何关于逸云阁的使用问题都可以问我。' }];
    root.innerHTML = `
    <div class="card" style="padding:0;overflow:hidden">
      <div class="ai-box">
        <div class="ai-log" id="aiLog">
          ${log.map(m => `<div class="ai-msg ${m.me ? 'me' : 'bot'}">
            <div class="av">${m.me ? '我' : '云'}</div>
            <div class="ai-bubble">${U.esc(m.text).replace(/\n/g, '<br>')}</div></div>`).join('')}
        </div>
        <div class="ai-quick">
          ${quick.map(q => `<button class="btn btn-ghost btn-sm" data-q="${U.esc(q)}">${U.esc(q)}</button>`).join('')}
        </div>
        <div class="ai-input">
          <input class="input" id="aiIn" placeholder="输入你的问题…" autocomplete="off">
          <button class="btn btn-primary" id="aiSend">发送</button>
        </div>
      </div>
    </div>`;
    const logEl = U.$('#aiLog', root), inp = U.$('#aiIn', root);
    const send = () => {
      const v = inp.value.trim(); if (!v) return;
      log.push({ me: true, text: v });
      const ans = reply(v);
      log.push({ me: false, text: ans });
      inp.value = '';
      render();
      const el = U.$('#aiLog'); if (el) el.scrollTop = el.scrollHeight;
    };
    U.$('#aiSend', root).onclick = send;
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
    root.querySelectorAll('[data-q]').forEach(b => b.onclick = () => { inp.value = b.dataset.q; send(); });
    const el = U.$('#aiLog'); if (el) el.scrollTop = el.scrollHeight;
  }
  Views.ai = { title: 'AI 助手', sub: '逸云小助手 · 本地规则问答', render() { render(); } };
  return { render };
})();

/* ---------- 帮助 ---------- */
const Help = (() => {
  function render() {
    const root = U.$('#view');
    if (!root || App.route !== 'help') return;
    const faq = [
      ['快速上手', '左侧（手机端底部）切换模块。主页聚合今日课程、待办与模板；待办支持模板一键导入；学员按标准编码自动拆解；老师名册是独立模块，可在学员档案下方找到。'],
      ['学员编码格式', '可在「数据管理 → 档案编码格式」自定义模板（用 [日期][年级学科][家长][抽成][课时费][课时长] 占位，自定分隔符与顺序）。默认：[日期]-[年级学科]-[家长]-[抽成]/[课时费]|[课时长]\n例：240815-高二数学-李妈妈-50/300|90\n系统自动拆成结构化字段，输入时实时预览，格式错误当场标红。'],
      ['中间人三本账', '每节课同时记录：家长流水（课时费）、老师课酬（课时费−抽成）、我的抽成。恒等式：流水 = 课酬 + 抽成。抽成存绝对金额、每节课冗余存价格快照，保证历史账目不被改写。'],
      ['可视化课表', '周视图时间轴可拖拽改时间，重叠自动并排+红框提示；月视图看密度；年视图看淡旺季。同一时段允许排两节课。'],
      ['试课回访', '学员标记「试课中」+ 填试课日期，次日自动在待办生成「回访XX妈妈试课体验」，幂等只生成一次。'],
      ['财务统计', '支持本月/上月/近30天/本年/自定义区间；年级饼图、老师课时排行、学员贡献、明细表；板块可排序与显隐。页面显示数据最近更新时间。'],
      ['数据备份', '数据仅存本机浏览器，不上传。设置-数据管理可导出/导入 JSON、载入演示数据、清空。换设备前务必导出备份。']
    ];
    root.innerHTML = `
    <div class="card">
      <div class="card-h"><h3>使用指南</h3></div>
      ${faq.map(([q, a]) => `<div class="link-card" style="box-shadow:none;margin-bottom:10px">
        <h4>${U.esc(q)}</h4><p class="muted" style="font-size:12.5px;line-height:1.8;white-space:pre-wrap">${U.esc(a)}</p></div>`).join('')}
      <div class="divider"></div>
      <p class="muted" style="font-size:12px">提示：手机端底部导航固定 5 个入口（主页 / 日历 / 待办 / 学员 / 我的），其余模块都在「我的」里。复杂操作已改为抽屉或分步弹窗，图表在手机端保留关键数据。</p>
    </div>`;
  }
  Views.help = { title: '帮助', sub: '逸云阁使用指南', render() { render(); } };
  return { render };
})();

/* ---------- 关联中心（待办 ↔ 学员） ---------- */
const Link = (() => {
  function render() {
    const root = U.$('#view');
    if (!root || App.route !== 'link') return;
    const linked = DB.data.todos.filter(t => t.studentId);
    const unlinked = DB.data.todos.filter(t => !t.studentId && !t.done);
    const opt = DB.data.students.map(s => `<option value="${s.id}">${U.esc(s.parentName)}（${U.esc(s.grade + s.subject)}）</option>`).join('');
    const optT = unlinked.map(t => `<option value="${t.id}">${U.esc(t.title)}</option>`).join('');

    root.innerHTML = `
    <div class="link-card">
      <h4>中间人关系</h4>
      <p class="muted" style="font-size:12.5px;line-height:1.8">你是连接「家长」与「老师」的中间人。每节课同时记录三笔：<b>家长流水</b>（课时费）、<b>老师课酬</b>（课时费−抽成）、<b>我的抽成</b>。恒等式：流水 = 课酬 + 抽成。</p>
    </div>

    <div class="link-card">
      <h4>已关联待办（${linked.length}）</h4>
      ${linked.length ? linked.map(t => {
        const s = DB.student(t.studentId);
        return `<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
          <span class="link-rel"><svg class="ico"><use href="#i-link"/></svg>${s ? U.esc(s.parentName) : '已删除'} · ${U.esc(s ? s.grade + s.subject : '')}</span>
          <span style="font-size:13px;flex:1;min-width:120px">${U.esc(t.title)}</span>
          <button class="btn btn-sm btn-ghost" data-act="unlink" data-id="${t.id}">解除</button></div>`;
      }).join('') : `<p class="muted" style="font-size:12.5px">还没有把待办关联到学员。把下面的待办和学员关联起来，方便跟进。</p>`}
    </div>

    <div class="link-card">
      <h4>快速关联</h4>
      ${optT ? `<div class="row">
        <div class="field"><label>待办</label><select class="input" id="lk_t">${optT}</select></div>
        <div class="field"><label>学员</label><select class="input" id="lk_s">${opt}</select></div>
      </div>
      <button class="btn btn-primary" data-act="doLink">关联</button>` : `<p class="muted" style="font-size:12.5px">没有可关联的未完成待办。</p>`}
    </div>`;

    U.rebind(root, 'link', e => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      if (b.dataset.act === 'unlink') {
        const t = DB.data.todos.find(x => x.id === b.dataset.id);
        if (t) { t.studentId = ''; DB.save(); render(); U.toast('已解除关联'); }
      } else if (b.dataset.act === 'doLink') {
        const t = U.$('#lk_t', root).value, s = U.$('#lk_s', root).value;
        const todo = DB.data.todos.find(x => x.id === t);
        if (todo) { todo.studentId = s; DB.save(); render(); U.toast('已关联'); }
      }
    });
  }
  Views.link = { title: '关联', sub: '待办与学员的关联管理', render() { render(); } };
  return { render };
})();

/* ---------- 更新日志 ---------- */
const Changelog = (() => {
  function render() {
    const root = U.$('#view');
    if (!root || App.route !== 'changelog') return;
    root.innerHTML = `
    <div class="card">
      <div class="card-h"><h3>更新日志</h3></div>
      <div class="log-ver">v1.3</div><div class="log-date">2026-08-02</div>
      <ul class="log-list">
        <li>档案编码格式可自定义：在「数据管理 → 档案编码格式」里用 [日期][年级学科][家长][抽成][课时费][课时长] 占位、自定分隔符与顺序，支持实时试解析预览。</li>
        <li>已存档案不受影响——年级/课时费/抽成等结构化字段独立保存，仅新建/编辑时按新格式解析。</li>
      </ul>
      <div class="divider"></div>
      <div class="log-ver">v1.2</div><div class="log-date">2026-08-02</div>
      <ul class="log-list">
        <li>财务统计：板块支持拖动排序 / 隐藏 / 改名（编辑模块），并支持「恢复默认布局」。</li>
        <li>新增「自定义统计块」：可自主添加 区间总览 / 按老师 / 按年级 / 按学员 / 按月走势 等图表块，随时改名、隐藏或删除。</li>
        <li>财务页新增「导出图片（PNG）」与「导出 CSV」，方便留存与对账（CSV 含合计，适配 Excel）。</li>
        <li>安全加固：支持登录密码锁（本地 AES 加密，忘记密码无法找回，请牢记）；云同步采用端到端加密（AES-GCM），数据只存你自己的私密 Gist，明文绝不出本机。</li>
        <li>三端统一：手机 / 平板 / 电脑共用同一 GitHub Token + 同步空间 ID 即可自动同步数据，并在任意 WiFi / 手机流量下通过公网地址打开。</li>
      </ul>
      <div class="divider"></div>
      <div class="log-ver">v1.1</div><div class="log-date">2026-08-02</div>
      <ul class="log-list">
        <li>焕新命名为「逸云阁」，仪表盘更名为「主页」。</li>
        <li>主页新增可编辑/可删除的「每日模板库」模块。</li>
        <li>新增 iOS 风格个人日历（日/周/月/年），事项挂在日期下，可勾选完成。</li>
        <li>老师名册拆为独立模块，放在「学员档案」下方；设置精简为「数据管理」。</li>
        <li>可视化课表支持 年/月/周 三种视图自由切换；财务统计恢复中间人三本账展示。</li>
        <li>全面适配手机端：底部 5 等分导航、单列重排、表格转列表、触控≥44px、无横向滚动。</li>
        <li>「我的」只保留搜索、AI 助手、帮助、更新日志四个工具入口。</li>
      </ul>
      <div class="divider"></div>
      <div class="log-ver">v1.0</div><div class="log-date">2026-08-01</div>
      <ul class="log-list">
        <li>初始版本：待办（模板/四象限/归档）、学员档案（标准编码解析）、可视化课表（周/月/年）、财务三本账、常用话术库、设置与备份。</li>
      </ul>
    </div>`;
  }
  Views.changelog = { title: '更新日志', sub: '版本记录', render() { render(); } };
  return { render };
})();
